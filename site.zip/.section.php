<?
$sSectionName = "Главная";
$arDirProperties = array(
   "description" => "Компания осуществляет продажу строительных материалов.",
   "keywords" => "продажа строительных материалов премиум класса",
   "robots" => "index, follow"
);
?>