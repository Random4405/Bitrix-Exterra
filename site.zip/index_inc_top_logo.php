<div class="logo">
 <a href="/"> <img src="/images/logo-white.png" alt="" class="img-responsive"> </a>
</div>